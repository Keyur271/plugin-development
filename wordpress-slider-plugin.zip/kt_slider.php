<?php

/*
Plugin Name: Slider Plugin
Plugin URI: http://projects.theaxontech.com/wp/test/
Description: Slider for WordPress
Version: 1.0
Author: Keyur Thakore
*/

function kt_init() {
    $args = array(
        'public' => true,
        'label' => 'WP Slider',
        'supports' => array(
            'title',
            'thumbnail'
        )
    );
    register_post_type('kt_images', $args);
}
add_action('init', 'kt_init');

add_action('wp_print_scripts', 'kt_register_scripts');
add_action('wp_print_styles', 'kt_register_styles');

function kt_register_scripts() {
    if (!is_admin()) {

        wp_register_script('kt_nivo-script', plugins_url('scripts/jquery.nivo.slider.js', __FILE__), array( 'jquery' ));
        wp_register_script('kt_script', plugins_url('scripts/script.js', __FILE__));

        wp_enqueue_script('kt_nivo-script');
        wp_enqueue_script('kt_script');
    }
}
 
function kt_register_styles() {
    wp_register_style('kt_styles', plugins_url('css/nivo-slider.css', __FILE__));
    wp_register_style('kt_styles_theme', plugins_url('css/default.css', __FILE__));

    wp_enqueue_style('kt_styles');
    wp_enqueue_style('kt_styles_theme');
}


add_image_size('kt_function', 600, 280, true);

add_theme_support( 'post-thumbnails' );

function kt_function($type='kt_function') {
    $args = array(
        'post_type' => 'kt_images',
        'posts_per_page' => 5
    );
    $result = '<div class="slider-wrapper theme-default">';
    $result .= '<div id="slider" class="nivoSlider">';

    $loop = new WP_Query($args);
    while ($loop->have_posts()) {
        $loop->the_post();
 
        $the_url = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), $type);
        $result .='<img title="'.get_the_title().'" src="' . $the_url[0] . '" data-thumb="' . $the_url[0] . '" alt=""/>';
    }
    $result .= '</div>';
    $result .='<div id = "htmlcaption" class = "nivo-html-caption">';
    $result .='<strong>This</strong> is an example of a <em>HTML</em> caption with <a href = "#">a link</a>.';
    $result .='</div>';
    $result .='</div>';
    return $result;
}

add_shortcode('kt-shortcode', 'kt_function');


?>